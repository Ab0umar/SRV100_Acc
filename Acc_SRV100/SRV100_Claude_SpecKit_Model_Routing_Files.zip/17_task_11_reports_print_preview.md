# Implement reports and print preview

## Assigned By
Claude generates the final detailed task using the task template.

## Preferred Owner Model
GPT-5 / Cursor

## Task Seed
Implement reports and print preview

## Important Note
This file is a seed. Claude must rewrite/expand it inside `/tasks` using:

- Owner Model
- Backup Model
- Tool
- Role
- Input
- Output
- Prompt
- Acceptance Criteria
