# Generate /plan

## Assigned By
Claude generates the final detailed task using the task template.

## Preferred Owner Model
Claude

## Task Seed
Generate /plan

## Important Note
This file is a seed. Claude must rewrite/expand it inside `/tasks` using:

- Owner Model
- Backup Model
- Tool
- Role
- Input
- Output
- Prompt
- Acceptance Criteria
